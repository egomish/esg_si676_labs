<?php
namespace Omeka\Entity\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
