<?php
namespace Omeka\Job\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
