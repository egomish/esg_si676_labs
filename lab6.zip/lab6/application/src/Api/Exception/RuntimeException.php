<?php
namespace Omeka\Api\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
