<?php
namespace Omeka\File\Exception;

interface ExceptionInterface
{
}
